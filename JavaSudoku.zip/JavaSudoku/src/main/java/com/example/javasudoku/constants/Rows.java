package com.example.javasudoku.constants;

public enum Rows {
    TOP,
    MIDDLE,
    BOTTOM
}
