package com.example.javasudoku.constants;

public enum GameState {
    COMPLETE,
    ACTIVE,
    NEW
}
